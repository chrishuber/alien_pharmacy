/*
 * Chris Huber <chuber2@mail.ccsf.edu>
 * CS211S, Jessica Masters
 * 09/20/2020
 * Assignment Three: Design Patterns
 */

public class DiseaseEvolver implements Evolver {

	@Override
	public void evolve( ) {
		System.out.println("This disease has evolved!");
	}
}
