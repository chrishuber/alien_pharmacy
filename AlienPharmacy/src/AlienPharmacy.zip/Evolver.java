/*
 * Chris Huber <chuber2@mail.ccsf.edu>
 * CS211S, Jessica Masters
 * 09/20/2020
 * Assignment Three: Design Patterns
 */

public interface Evolver {
	public void evolve();
}
